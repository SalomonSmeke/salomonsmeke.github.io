define(function(require) {
  require(['./config'], function(config) {
    require(['./app']);
  });
});
