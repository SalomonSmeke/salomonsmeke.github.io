define(function(require) {
  var Ember = require('ember');

  return Ember.Controller;
});
